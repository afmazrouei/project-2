/*! \file MovieMake.cpp
 * Movie maker file based on Window Media Software Development Kit.
 * Writes video and stereo audio movie files based on
 * supply of audio and video data frame by frame.
 * \version 2.10 10-28-12 Revised to use CGrImage. Documentation updates.
 */

#include "pch.h"
#include <vector>
#include <cassert>
#include <iostream>

#include "moviemake.h"
#include <wmsysprf.h>
#include <mmreg.h>

using namespace std;

/*! \brief Constructor */
CMovieMake::CMovieMake()
     : m_isopen(false), m_audiostream(-1), m_videostream(-1),
     m_audioTime(0), m_videoTime(0), m_width(0), m_height(0),
     m_fps(0), m_numChannels(0), m_sampleRate(0), m_bitsPerSample(0) {
     CoInitialize(NULL);
     m_profileName = L"profile720x480.prx";  // Default profile name
}

/*! \brief Destructor */
CMovieMake::~CMovieMake() {
     Close();
     CoUninitialize();
}

/*! \brief Open a video file for output.
 * \param p_filename File to open
 * \returns true if successful
 */
bool CMovieMake::Open(const TCHAR* p_filename) {
     // Ensure the previous file is closed
     Close();

     m_audiostream = -1;
     m_videostream = -1;

     // Create the writer object
     HRESULT r = WMCreateWriter(NULL, &m_writer);
     if (r != S_OK) {
          AfxMessageBox(TEXT("Failed to create file writer"));
          return false;
     }

     if (!ObtainProfile()) {
          m_writer.Release();
          return false;
     }

     // Set the profile for the writer
     r = m_writer->SetProfile(m_profile);
     if (r != S_OK) {
          m_writer.Release();
          m_profile.Release();
          AfxMessageBox(TEXT("Failed to set the profile for the writer"));
          return false;
     }

     // Set the file name
#if UNICODE
     r = m_writer->SetOutputFilename(p_filename);
#else
     std::vector<WCHAR> wfilename(strlen(p_filename) + 1);
     MultiByteToWideChar(CP_ACP, 0, p_filename, -1, &wfilename[0], int(wfilename.size()));
     r = m_writer->SetOutputFilename(&wfilename[0]);
#endif
     if (r != S_OK) {
          m_writer.Release();
          AfxMessageBox(TEXT("Failed to set output filename"));
          return false;
     }

     DWORD inputCount;
     m_writer->GetInputCount(&inputCount);
     assert(inputCount == 2);  // Expect exactly two streams: audio and video

     r = m_writer->BeginWriting();
     if (r != S_OK) {
          AfxMessageBox(TEXT("Failed to begin writing"));
          m_writer.Release();
          return false;
     }

     m_audioTime = m_videoTime = 0;
     m_isopen = true;
     m_filename = p_filename;

     return true;
}

/*! \brief Obtain a profile from a file.
 * The file name is specified in m_profileName.
 * \returns true if successful
 */
bool CMovieMake::ObtainProfile() {
     // Obtain a profile manager
     CComPtr<IWMProfileManager> profileManager;
     HRESULT r = WMCreateProfileManager(&profileManager);
     if (r != S_OK) {
          AfxMessageBox(TEXT("Failed to create a profile manager for video output"));
          return false;
     }

     // Open the profile file
     HANDLE hFile = CreateFileW(m_profileName.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL,
          OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
     if (hFile == INVALID_HANDLE_VALUE) {
          AfxMessageBox(TEXT("Unable to open profile file."));
          return false;
     }

     DWORD fileSize = GetFileSize(hFile, NULL);
     if (fileSize == INVALID_FILE_SIZE) {
          CloseHandle(hFile);
          AfxMessageBox(TEXT("Unable to read profile file."));
          return false;
     }

     // Allocate memory for the profile buffer
     std::vector<BYTE> profileBuffer(fileSize + sizeof(WCHAR));
     memset(profileBuffer.data(), 0, profileBuffer.size());

     DWORD bytesRead;
     if (!ReadFile(hFile, profileBuffer.data(), fileSize, &bytesRead, NULL)) {
          CloseHandle(hFile);
          AfxMessageBox(TEXT("Unable to read profile file."));
          return false;
     }

     CloseHandle(hFile);

     // Load the profile from the buffer
     HRESULT hr = profileManager->LoadProfileByData((WCHAR*)profileBuffer.data(), &m_profile);
     if (hr != S_OK) {
          AfxMessageBox(TEXT("Unable to read profile data."));
          return false;
     }

     // Determine stream information
     DWORD streamCount;
     m_profile->GetStreamCount(&streamCount);
     for (DWORD i = 0; i < streamCount; ++i) {
          CComPtr<IWMStreamConfig> streamConfig;
          m_profile->GetStream(i, &streamConfig);

          // Get media properties
          CComPtr<IWMMediaProps> mediaProps;
          hr = streamConfig->QueryInterface(IID_IWMMediaProps, (void**)&mediaProps);
          if (hr != S_OK) continue;

          // Get the media type
          std::vector<BYTE> mediaTypeBuffer;
          DWORD mediaTypeSize = 0;
          mediaProps->GetMediaType(NULL, &mediaTypeSize);
          mediaTypeBuffer.resize(mediaTypeSize);
          mediaProps->GetMediaType((WM_MEDIA_TYPE*)mediaTypeBuffer.data(), &mediaTypeSize);

          WM_MEDIA_TYPE* mediaType = (WM_MEDIA_TYPE*)mediaTypeBuffer.data();
          if (mediaType->majortype == WMMEDIATYPE_Video) {
               if (m_videostream >= 0) continue;
               m_videostream = i;

               WMVIDEOINFOHEADER* videoInfo = (WMVIDEOINFOHEADER*)mediaType->pbFormat;
               m_width = videoInfo->bmiHeader.biWidth;
               m_height = videoInfo->bmiHeader.biHeight;
               m_fps = 10000000. / videoInfo->AvgTimePerFrame;
               m_spf = 1. / m_fps;
          }
          else if (mediaType->majortype == WMMEDIATYPE_Audio) {
               if (m_audiostream >= 0) continue;
               m_audiostream = i;

               WAVEFORMATEX* audioInfo = (WAVEFORMATEX*)mediaType->pbFormat;
               m_numChannels = audioInfo->nChannels;
               m_sampleRate = audioInfo->nSamplesPerSec;
               m_bitsPerSample = audioInfo->wBitsPerSample;
               m_samplePeriod = 1. / double(m_sampleRate);
          }
     }

     return true;
}

/*! \brief Close the video file. */
bool CMovieMake::Close() {
     if (!m_isopen) return true;

     HRESULT r = m_writer->Flush();
     r = m_writer->EndWriting();

     m_writer.Release();
     m_profile.Release();
     m_isopen = false;

     return true;
}

/*! \brief Write an image to the video file.
 * \param p_image Image to write
 * \returns true if successful
 */
bool CMovieMake::WriteImage(const CGrImage& p_image) {
     if (!m_isopen || m_videostream < 0) return false;
     assert(p_image.GetWidth() == m_width && p_image.GetHeight() == m_height);

     return WriteImage(p_image.GetRow(0));
}

/*! \brief Write audio frames to the video file.
 * \param p_audio Audio sample frames to write
 * \returns true if successful
 */
bool CMovieMake::WriteAudio(const std::vector<short>& p_audio) {
     return WriteAudio(p_audio.data(), static_cast<int>(p_audio.size()) / m_numChannels);
}

bool CMovieMake::WriteAudio(const short* p_audio, int frameCount) {
     if (!m_isopen || m_audiostream < 0) return false;

     CComPtr<INSSBuffer> audioSample;
     BYTE* buffer;

     m_writer->AllocateSample(frameCount * 2 * m_numChannels, &audioSample);
     audioSample->GetBuffer(&buffer);

     memcpy(buffer, p_audio, frameCount * 2 * m_numChannels);

     HRESULT r = m_writer->WriteSample(m_audiostream, QWORD(m_audioTime * 10000000.), 0, audioSample);
     assert(r == S_OK);

     m_audioTime += frameCount * m_samplePeriod;

     return true;
}
bool CMovieMake::WriteImage(const BYTE* p_image)
{
     if (!m_isopen)
          return false;

     if (m_videostream < 0)
          return false;

     BYTE* buffer;
     CComPtr<INSSBuffer> videoSample;

     int samplesize = m_width * m_height * 3; 
     m_writer->AllocateSample(samplesize, &videoSample);
     videoSample->GetBuffer(&buffer);

     memcpy(buffer, p_image, samplesize);

     HRESULT r = m_writer->WriteSample(m_videostream, QWORD(m_videoTime * 10000000.), 0, videoSample);
     assert(r == S_OK);

     m_videoTime += m_spf;

     videoSample.Release();

     return true;
}
