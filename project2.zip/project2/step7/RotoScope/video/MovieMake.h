#pragma once

#include <string>
#include <vector>
#include <wmsdk.h>
#include "graphics/GrImage.h"

//! Class that is used to create a movie file
/*!
 * Class that can be used to create a movie file.
 *
 * The output format is determined by a profile created by the
 * program WMProEdt, the Windows profile editor. Some example profiles
 * have been provided. The default profile is profile720x480.prx, which
 * creates 720 by 480 progressive scan output at 29.97 frames per second.
 */
class CMovieMake
{
public:
     CMovieMake();
     ~CMovieMake();

     bool Open(const wchar_t* p_filename); //!< Opens the movie file for output
     bool Close();                         //!< Closes the currently opened movie file

     //! \brief Returns true if the movie file is open
     //! \returns true if the movie file is open
     bool IsOpen() const { return m_isopen; }

     bool WriteImage(const CGrImage& p_image); //!< Writes a video frame to the output file
     bool WriteAudio(const std::vector<short>& p_audio); //!< Writes audio samples to the output file
     bool WriteAudio(const short* p_audio, int p_framecnt); //!< Writes a specified number of audio samples

     //! \brief Write raw image data
     //! \param p_image Pointer to raw image byte data
     //! \returns true if successful
     bool WriteImage(const BYTE* p_image); //!< Now public for direct access

     //! \brief Get the current video frame time
     //! \returns The time for the next frame to be written
     double GetImageTime() const { return m_videoTime; }

     //! \brief Get the current audio time
     //! \returns The time for the next audio sample to be written
     double GetAudioTime() const { return m_audioTime; }

     //! \brief Get the number of audio channels
     //! \returns Number of audio channels in the output file
     int GetNumChannels() const { return m_numChannels; }

     //! \brief Get the sample rate for audio
     //! \returns Sample rate in samples per second
     double GetSampleRate() const { return m_sampleRate; }

     //! \brief Get the average number of bits per audio sample
     //! \returns Bits per sample
     int GetBitPerSample() const { return m_bitsPerSample; }

     //! \brief Get the width of the video frames
     //! \returns Width of the video frame
     int GetWidth() const { return m_width; }

     //! \brief Get the height of the video frames
     //! \returns Height of the video frame
     int GetHeight() const { return m_height; }

     //! \brief Get the frames per second (FPS) of the video
     //! \returns Frames per second
     double GetFPS() const { return m_fps; }

     //! \brief Get the profile name
     //! \returns Name of the profile used for the video output
     const wchar_t* GetProfileName() const { return m_profileName.c_str(); }

     //! \brief Set the profile name
     //! \param name Name of the new profile
     void SetProfileName(const wchar_t* name) { m_profileName = name; }

     //! \brief Get the filename of the last successfully opened file
     //! \returns Name of the last opened file
     const wchar_t* GetFilename() const { return m_filename.c_str(); }

private:
     bool ObtainProfile(); //!< Loads the profile from the profile file

     // Windows Media components
     CComPtr<IWMWriter>  m_writer;    //!< Media writer object
     CComPtr<IWMProfile> m_profile;   //!< Profile object for defining output parameters

     // File information
     std::wstring m_filename;         //!< Name of the currently opened output file
     std::wstring m_profileName;      //!< Name of the profile used for output

     // Timekeeping
     double m_videoTime;              //!< Current video stream time
     double m_audioTime;              //!< Current audio stream time
     bool m_isopen;                   //!< Indicates if a file is currently open

     // Stream indices
     int m_videostream;               //!< Index of the video stream
     int m_audiostream;               //!< Index of the audio stream

     // Audio properties
     int m_numChannels;               //!< Number of audio channels
     int m_sampleRate;                //!< Audio sample rate in samples per second
     double m_samplePeriod;           //!< Duration of a single audio sample
     int m_bitsPerSample;             //!< Bits per audio sample

     // Video properties
     int m_width;                     //!< Width of the video frames
     int m_height;                    //!< Height of the video frames
     double m_fps;                    //!< Frames per second of the video
     double m_spf;                    //!< Seconds per frame (1 / FPS)
};
