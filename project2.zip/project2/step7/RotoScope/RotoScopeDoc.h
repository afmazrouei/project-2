/*! \file RotoScopeDoc.h
 *
 * Header file for the RotoScope document class
 * \author Charles B. Owen
 */

#pragma once

#include <vector>
#include <list>
#include <stack>
#include <atlimage.h>
#include "video/MovieSource.h"
#include "video/MovieMake.h"
#include "audio/DirSoundSource.h"
#include "graphics/GrImage.h"
#include "LineDlg.h"

 //! Rotoscope document class
 /*! RotoScope document class */
class CRotoScopeDoc : public CDocument
{
protected:
     CRotoScopeDoc();
     virtual ~CRotoScopeDoc();
     DECLARE_DYNCREATE(CRotoScopeDoc)

public:
     // Document overrides
     virtual BOOL OnNewDocument() override;
     virtual BOOL OnSaveDocument(LPCTSTR lpszPathName) override;
     virtual BOOL OnOpenDocument(LPCTSTR lpszPathName) override;

     // Video frame properties
     int GetFrameWidth() const;
     int GetFrameHeight() const;
     int GetFrameCount() const;
     CImage* GetFrame(int frameIndex);
     void SetFrame(int frameIndex, CImage* frame);

     // Video generation
     void GenerateOutputVideo();
     std::wstring GetOutputVideoPath() const;

     // Drawing and editing methods
     void Mouse(int p_x, int p_y);
     void DrawImage();
     void DrawLine(CGrImage& image, int x1, int y1, int x2, int y2, int width, int b, int g, int r);
     void DrawBird(CGrImage& image, int x1, int y1);
     void RotateImage(CGrImage& image, int theta);
     void SetImage(const CGrImage& image);
     void ApplyGarbageMask(CGrImage& image, RECT garbageMask, COLORREF fillColor);
     void ApplyChromaKey(CGrImage& image, COLORREF keyColor, COLORREF replaceColor, RECT bounds);
     bool IsColorMatch(COLORREF color1, COLORREF color2, int tolerance = 30);

     // Mask management
     void ToggleMask();  // Toggles mask visibility
     void ClearMask();   // Clears the current mask

     // XML and movie data handling
     void SaveMovieData(IXMLDOMDocument* xmlDoc, IXMLDOMNode* inNode);
     void XmlLoadMovie(IXMLDOMNode* xml);
     void XmlLoadFrame(IXMLDOMNode* xml);

     // Undo stack and state restoration
     void UndoLastAction();
     void PlaceBird(CGrImage& image, int x, int y);

     // Getter for the current image
     const CGrImage& GetImage() const { return m_image; }

#ifdef _DEBUG
     virtual void AssertValid() const override;
     virtual void Dump(CDumpContext& dc) const override;
#endif

protected:
     DECLARE_MESSAGE_MAP()

private:
     // Video and audio management
     CMovieSource m_moviesource;           // Video input source
     CMovieMake m_moviemake;               // Video output
     CDirSoundSource m_backaudio;          // Background audio

     // Frame and editing data
     CGrImage m_image;                     // Current image being edited
     std::vector<CImage*> m_frames;        // List of video frames
     std::vector<short> m_audio;           // Audio data
     int m_movieframe;                     // Current frame index
     std::wstring m_outputVideoPath;       // Path to output video

     // Mask and drawing parameters
     CGrImage m_maskImage;                 // Image representing the mask
     bool m_maskVisible;                   // Indicates whether the mask is visible
     std::vector<std::list<CPoint>> m_draw; // List of points for each frame
     CGrImage m_initial;                   // Initial unmodified frame
     CLineDlg m_dlg;                       // Line dialog
     CGrImage m_bird;                      // Bird image overlay
     int m_x1, m_y1, m_x2, m_y2;           // Line coordinates
     int m_b, m_g, m_r;                    // Color (blue, green, red)
     int m_width;                          // Line width
     int m_theta;                          // Rotation angle
     int m_mode;                           // Mouse mode
     int m_dot_count;                      // Dot count for certain effects

     std::stack<CGrImage> m_images;        // Stack for undo functionality

     // Internal helper methods
     void CreateOneFrame();
     void MessagePump();

     // Command handlers
     afx_msg void OnMoviesOpensourcemovie();
     afx_msg void OnMoviesOpenoutputmovie();
     afx_msg void OnFramesCreateoneframe();
     afx_msg void OnFramesWriteoneframe();
     afx_msg void OnUpdateFramesWriteoneframe(CCmdUI* pCmdUI);
     afx_msg void OnMoviesClosesourcemovie();
     afx_msg void OnUpdateMoviesClosesourcemovie(CCmdUI* pCmdUI);
     afx_msg void OnMoviesCloseoutputmovie();
     afx_msg void OnUpdateMoviesCloseoutputmovie(CCmdUI* pCmdUI);
     afx_msg void OnFramesWritethencreateoneframe();
     afx_msg void OnUpdateFramesWritethencreateoneframe(CCmdUI* pCmdUI);
     afx_msg void OnFramesWritethencreateonesecond();
     afx_msg void OnFramesWritethencreateremaining();
     afx_msg void OnMoviesOpenbackgroundaudio();
     afx_msg void OnMoviesClosebackgroundaudio();
     afx_msg void OnUpdateMoviesClosebackgroundaudio(CCmdUI* pCmdUI);
     afx_msg void OnEditClearframe();
     afx_msg void OnEditDrawline();
     afx_msg void OnEditPlaceBird();
     afx_msg void OnEditRotateImage();
     afx_msg void OnEditSetvariables();
     afx_msg void OnMousemodePen();
     afx_msg void OnMousemodeLine();
     afx_msg void OnMousemodeBird();
     afx_msg void OnEditUndo32793();
     afx_msg void OnEditGarbageMask();
     afx_msg void OnEditChromaKey();
};
