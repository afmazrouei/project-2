#pragma once

#include <msxml2.h>
#include <atlbase.h> // For CComPtr

//! Advance to the next sibling node in an XML document
/*!
 * This function accepts a reference to a node pointer
 * and advances it to the next sibling node.
 * \param node Reference to a CComPtr<IXMLDOMNode> that will be updated
 *        to point to the next sibling node.
 */
inline void NextNode(CComPtr<IXMLDOMNode>& node)
{
     if (node) // Ensure the node is valid before proceeding
     {
          CComPtr<IXMLDOMNode> next;
          if (SUCCEEDED(node->get_nextSibling(&next)))
          {
               node = next; // Update the input node to the next sibling
          }
          else
          {
               node = nullptr; // Set to nullptr if there is no next sibling
          }
     }
}
