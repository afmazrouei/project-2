//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RotoScope.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_RotoScopeTYPE               129
#define IDD_LINEDLG                     130
#define IDC_X1                          1000
#define IDC_X2                          1001
#define IDC_Y1                          1002
#define IDC_Y2                          1003
#define IDC_B                           1004
#define IDC_G                           1005
#define IDC_R                           1006
#define IDC_W                           1007
#define ID_MOVIES_OPENSOURCEMOVIE       32771
#define ID_MOVIES_OPENOUTPUTMOVIE       32772
#define ID_MOVIES_CLOSEOUTPUTMOVIE      32773
#define ID_FRAMES_READONEFRAME          32774
#define ID_FRAMES_CREATEONEFRAME        32775
#define ID_FRAMES_WRITEONEFRAME         32777
#define ID_MOVIES_CLOSESOURCEMOVIE      32778
#define ID_FRAMES_WRITETHENCREATEONEFRAME 32779
#define ID_FRAMES_WRITETHENCREATEONESECOND 32781
#define ID_FRAMES_WRITETHENCREATEREMAINING 32782
#define ID_MOVIES_OPENBACKGROUNDAUDIO   32783
#define ID_MOVIES_CLOSEBACKGROUNDAUDIO  32784
#define ID_EDIT_CLEARFRAME              32785
#define ID_EDIT_DRAWLINE                32786
#define ID_EDIT_PLACEBIRD               32787
#define ID_EDIT_ROTATEIMAGE             32788
#define ID_EDIT_SETVARIABLES            32789
#define ID_MOUSEMODE_PEN                32790
#define ID_MOUSEMODE_LINE               32791
#define ID_MOUSEMODE_BIRD               32792
#define ID_EDIT_UNDO32793               32793
#define ID_EDIT_GARBAGEMASK             32794
#define ID_EDIT_CHROMAKEY               32795

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
