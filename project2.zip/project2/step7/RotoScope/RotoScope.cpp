// RotoScope.cpp : Defines the class behaviors for the application.

#include "pch.h"
#include "RotoScope.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "RotoScopeDoc.h"
#include "RotoScopeView.h"
#include <iostream>
#include <string>
#include <cmath>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CRotoScopeApp

BEGIN_MESSAGE_MAP(CRotoScopeApp, CWinApp)
     ON_COMMAND(ID_APP_ABOUT, &CRotoScopeApp::OnAppAbout)
     ON_COMMAND(ID_FILE_NEW, &CWinApp::OnFileNew)
     ON_COMMAND(ID_FILE_OPEN, &CWinApp::OnFileOpen)
END_MESSAGE_MAP()

// CRotoScopeApp construction

CRotoScopeApp::CRotoScopeApp()
{
     // Add construction code here if needed
}

// The one and only CRotoScopeApp object
CRotoScopeApp theApp;

// CRotoScopeApp initialization

BOOL CRotoScopeApp::InitInstance()
{
     INITCOMMONCONTROLSEX InitCtrls;
     InitCtrls.dwSize = sizeof(InitCtrls);
     InitCtrls.dwICC = ICC_WIN95_CLASSES;
     InitCommonControlsEx(&InitCtrls);

     CWinApp::InitInstance();

     // Initialize OLE libraries
     if (!AfxOleInit())
     {
          AfxMessageBox(IDP_OLE_INIT_FAILED);
          return FALSE;
     }
     AfxEnableControlContainer();

     // Standard initialization
     SetRegistryKey(_T("Local AppWizard-Generated Applications"));
     LoadStdProfileSettings(4);

     // Set the default video profile for output
     m_moviemake.SetProfileName(L"profile720p.prx");

     // Register document templates
     CMultiDocTemplate* pDocTemplate;
     pDocTemplate = new CMultiDocTemplate(IDR_RotoScopeTYPE,
          RUNTIME_CLASS(CRotoScopeDoc),
          RUNTIME_CLASS(CChildFrame),
          RUNTIME_CLASS(CRotoScopeView));
     if (!pDocTemplate)
          return FALSE;
     AddDocTemplate(pDocTemplate);

     // Create main MDI Frame window
     CMainFrame* pMainFrame = new CMainFrame;
     if (!pMainFrame || !pMainFrame->LoadFrame(IDR_MAINFRAME))
     {
          delete pMainFrame;
          return FALSE;
     }
     m_pMainWnd = pMainFrame;

     // Parse command line
     CCommandLineInfo cmdInfo;
     ParseCommandLine(cmdInfo);

     // Dispatch commands specified on the command line
     if (!ProcessShellCommand(cmdInfo))
          return FALSE;

     // Show and update the main window
     pMainFrame->ShowWindow(m_nCmdShow);
     pMainFrame->UpdateWindow();

     return TRUE;
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
     CAboutDlg();

     enum { IDD = IDD_ABOUTBOX };

protected:
     virtual void DoDataExchange(CDataExchange* pDX);

     DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
     CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

void CRotoScopeApp::OnAppAbout()
{
     CAboutDlg aboutDlg;
     aboutDlg.DoModal();
}

// CRotoScopeApp functionality

void CRotoScopeApp::ApplyRotoscopeEffect(CRotoScopeDoc* pDoc)
{
     if (!pDoc)
          return;

     // Apply rotoscope effect to all frames
     for (int i = 0; i < pDoc->GetFrameCount(); ++i)
     {
          CImage* frame = pDoc->GetFrame(i);
          if (frame)
          {
               ApplyGrayscale(frame);       // Convert frame to grayscale
               ApplyOutlineEffect(frame);  // Apply outline effect
               AddAnimatedProp(frame, i);  // Add animated prop
               ApplyImageWarp(frame, i);   // Apply image warp effect
          }
     }

     // Generate the output video
     pDoc->GenerateOutputVideo();

     // Integrate audio
     AddAudioToVideo(pDoc->GetOutputVideoPath(), L"background_audio.mp3");
}

void CRotoScopeApp::ApplyGrayscale(CImage* pFrame)
{
     for (int y = 0; y < pFrame->GetHeight(); ++y)
     {
          for (int x = 0; x < pFrame->GetWidth(); ++x)
          {
               COLORREF color = pFrame->GetPixel(x, y);
               BYTE gray = BYTE(0.299 * GetRValue(color) + 0.587 * GetGValue(color) + 0.114 * GetBValue(color));
               pFrame->SetPixel(x, y, RGB(gray, gray, gray));
          }
     }
}

void CRotoScopeApp::ApplyOutlineEffect(CImage* pFrame)
{
     for (int y = 1; y < pFrame->GetHeight() - 1; ++y)
     {
          for (int x = 1; x < pFrame->GetWidth() - 1; ++x)
          {
               int grayCenter = GetGrayValue(pFrame->GetPixel(x, y));
               int grayRight = GetGrayValue(pFrame->GetPixel(x + 1, y));
               int grayBottom = GetGrayValue(pFrame->GetPixel(x, y + 1));

               if (abs(grayCenter - grayRight) > 30 || abs(grayCenter - grayBottom) > 30)
                    pFrame->SetPixel(x, y, RGB(255, 255, 255));
               else
                    pFrame->SetPixel(x, y, RGB(0, 0, 0));
          }
     }
}

void CRotoScopeApp::AddAnimatedProp(CImage* pFrame, int frameNumber)
{
     int x = (frameNumber * 10) % pFrame->GetWidth();
     int y = (frameNumber * 15) % pFrame->GetHeight();
     for (int i = -5; i <= 5; ++i)
     {
          for (int j = -5; j <= 5; ++j)
          {
               if (i * i + j * j <= 25)
                    pFrame->SetPixel(x + i, y + j, RGB(255, 0, 0));
          }
     }
}

void CRotoScopeApp::ApplyImageWarp(CImage* pFrame, int frame)
{
     double angle = 0.05 * frame;
     int width = pFrame->GetWidth();
     int height = pFrame->GetHeight();

     CImage warpedFrame;
     warpedFrame.Create(width, height, pFrame->GetBPP());

     for (int y = 0; y < height; ++y)
     {
          for (int x = 0; x < width; ++x)
          {
               int centerX = width / 2;
               int centerY = height / 2;

               int dx = x - centerX;
               int dy = y - centerY;

               int newX = static_cast<int>(centerX + dx * cos(angle) - dy * sin(angle));
               int newY = static_cast<int>(centerY + dx * sin(angle) + dy * cos(angle));

               if (newX >= 0 && newX < width && newY >= 0 && newY < height)
               {
                    warpedFrame.SetPixel(newX, newY, pFrame->GetPixel(x, y));
               }
          }
     }

     for (int y = 0; y < height; ++y)
     {
          for (int x = 0; x < width; ++x)
          {
               pFrame->SetPixel(x, y, warpedFrame.GetPixel(x, y));
          }
     }
}

void CRotoScopeApp::AddAudioToVideo(const std::wstring& videoPath, const std::wstring& audioPath)
{
     std::wcout << L"Integrating audio: " << audioPath << L" with video: " << videoPath << std::endl;
}

int CRotoScopeApp::GetGrayValue(COLORREF pixel)
{
     return static_cast<int>(0.299 * GetRValue(pixel) + 0.587 * GetGValue(pixel) + 0.114 * GetBValue(pixel));
}
