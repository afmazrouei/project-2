// RotoScope.h : main header file for the RotoScope application
//
#pragma once

#ifndef __AFXWIN_H__
#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"       // Main symbols
#include "video/MovieMake.h"
#include <string>
#include <atlimage.h>

// Forward declaration of CRotoScopeDoc
class CRotoScopeDoc;

// CRotoScopeApp:
// See RotoScope.cpp for the implementation of this class
//

class CRotoScopeApp : public CWinApp
{
public:
     CRotoScopeApp();

     // Overrides
public:
     virtual BOOL InitInstance();

     // Video and Effects
     void ApplyRotoscopeEffect(CRotoScopeDoc* pDoc);
     void ApplyGrayscale(CImage* pFrame); // Grayscale effect
     void ApplyOutlineEffect(CImage* pFrame); // Outline effect
     void AddAnimatedProp(CImage* pFrame, int frameNumber); // Add animated prop to video
     void ApplyImageWarp(CImage* pFrame, int frame); // Warp image for effect

     // Chromakeying and Helper Functions
     void ApplyChromakey(CImage* pFrame, COLORREF backgroundColor, RECT garbageMask); // Chromakey function
     bool IsGreen(COLORREF pixel); // Check if pixel is green
     int GetGrayValue(COLORREF pixel); // Helper to get grayscale value of a pixel

     // Audio Integration
     void AddAudioToVideo(const std::wstring& videoPath, const std::wstring& audioPath); // Add audio to video

     // About Dialog
     afx_msg void OnAppAbout();
     DECLARE_MESSAGE_MAP()

private:
     CMovieMake m_moviemake;  // Instance of CMovieMake for video output
};

// Global application object
extern CRotoScopeApp theApp;
