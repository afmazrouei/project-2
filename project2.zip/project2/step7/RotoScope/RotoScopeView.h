/*! \file RotoScopeView.h
 *
 * Interface of the CRotoScopeView class
 * \author Charles B. Owen
 */

#pragma once

#include "RotoScopeDoc.h"

 //! Rotoscope view class
 /*! The view class for the rotoscope document */
class CRotoScopeView : public CScrollView
{
protected:
     //! Create from serialization only
     CRotoScopeView();
     DECLARE_DYNCREATE(CRotoScopeView)

     // Attributes
public:
     //! Get a pointer to the document object
     /*! \returns Pointer to CRotoScopeDoc document object */
     CRotoScopeDoc* GetDocument() const;

     // Operations
public:

     // Overrides
public:
     //! Function called to draw the view
     /*! \param pDC Pointer to a device context */
     virtual void OnDraw(CDC* pDC) override;

     //! Function called prior to the creation of the window
     /*! \param cs A creation structure
      * \returns true if successful */
     virtual BOOL PreCreateWindow(CREATESTRUCT& cs) override;

protected:

     // Implementation
public:
     //! Destructor
     virtual ~CRotoScopeView();

#ifdef _DEBUG
     //! Debugging support
     virtual void AssertValid() const override;

     //! Debugging support
     virtual void Dump(CDumpContext& dc) const override;
#endif

protected:

     // Generated message map functions
protected:
     //! Message map declaration
     DECLARE_MESSAGE_MAP()

private:
     //! Handler for erasing the background
     /*! Prevents flickering by avoiding default background erasing */
     afx_msg BOOL OnEraseBkgnd(CDC* pDC);

     //! Handler for left mouse button down
     /*! \param nFlags Indicates whether various virtual keys are down
      * \param point Specifies the x- and y- coordinate of the cursor */
     afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

     //! Handler for mouse movement
     /*! \param nFlags Indicates whether various virtual keys are down
      * \param point Specifies the x- and y- coordinate of the cursor */
     afx_msg void OnMouseMove(UINT nFlags, CPoint point);

     //! Handler for right mouse button down
     /*! \param nFlags Indicates whether various virtual keys are down
      * \param point Specifies the x- and y- coordinate of the cursor */
     afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

     //! Handler for keyboard input
     /*! \param nChar The character code of the key pressed
      * \param nRepCnt Repeat count
      * \param nFlags Indicates whether various virtual keys are down */
     afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

private:
     //! Background color for the view
     COLORREF m_bgColor;

     //! Indicates if the user is currently dragging the mouse
     bool m_dragging;
};

#ifndef _DEBUG  // debug version in RotoScopeView.cpp
inline CRotoScopeDoc* CRotoScopeView::GetDocument() const
{
     return reinterpret_cast<CRotoScopeDoc*>(m_pDocument);
}
#endif
