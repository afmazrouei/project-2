// RotoScopeView.cpp : implementation of the CRotoScopeView class

#include "pch.h"
#include "RotoScope.h"

#include "RotoScopeDoc.h"
#include "RotoScopeView.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace std;

// CRotoScopeView

IMPLEMENT_DYNCREATE(CRotoScopeView, CScrollView)

BEGIN_MESSAGE_MAP(CRotoScopeView, CScrollView)
     ON_WM_ERASEBKGND()
     ON_WM_LBUTTONDOWN()
     ON_WM_MOUSEMOVE()
     ON_WM_RBUTTONDOWN()
     ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CRotoScopeView construction/destruction

CRotoScopeView::CRotoScopeView()
{
     m_dragging = false; // Initialize dragging state
     m_bgColor = RGB(128, 128, 128); // Default background color (gray)
}

CRotoScopeView::~CRotoScopeView()
{
}

//! Function called prior to creation of window
/*! \param cs A creation structure
 * \returns true if successful */
BOOL CRotoScopeView::PreCreateWindow(CREATESTRUCT& cs)
{
     SetScrollSizes(MM_TEXT, CSize(720, 480)); // Initial scroll size
     return CScrollView::PreCreateWindow(cs);
}

//! CRotoScopeView drawing
/*! \param pDC Pointer to a device context to draw on */
void CRotoScopeView::OnDraw(CDC* pDC)
{
     CRotoScopeDoc* pDoc = GetDocument();
     ASSERT_VALID(pDoc);
     if (!pDoc) return;

     // Get the image to draw
     const CGrImage& image = pDoc->GetImage();

     // Validate the image size
     if (image.GetWidth() == 0 || image.GetHeight() == 0) {
          return;
     }

     CSize imgSize(image.GetWidth(), image.GetHeight());

     // Draw the background
     CRect rect;
     GetClientRect(&rect);
     CBrush bgBrush(m_bgColor);
     pDC->FillRect(rect, &bgBrush);

     if (rect.Width() > imgSize.cx || rect.Height() > imgSize.cy) {
          // Fill areas outside the image with the background color
          CRect rectRight(rect);
          if (rect.Width() > imgSize.cx) {
               rectRight.left = imgSize.cx;
               pDC->FillRect(rectRight, &bgBrush);
          }
          if (rect.Height() > imgSize.cy) {
               rectRight.top = imgSize.cy;
               rectRight.right = imgSize.cx;
               pDC->FillRect(rectRight, &bgBrush);
          }
     }

     // Update scroll sizes if needed
     SetScrollSizes(MM_TEXT, imgSize);

     // Draw the image
     image.Draw(pDC, 0, 0);
}

// CRotoScopeView diagnostics

#ifdef _DEBUG
void CRotoScopeView::AssertValid() const
{
     CView::AssertValid();
}

void CRotoScopeView::Dump(CDumpContext& dc) const
{
     CView::Dump(dc);
}

CRotoScopeDoc* CRotoScopeView::GetDocument() const // non-debug version is inline
{
     ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRotoScopeDoc)));
     return (CRotoScopeDoc*)m_pDocument;
}
#endif //_DEBUG

// CRotoScopeView message handlers

BOOL CRotoScopeView::OnEraseBkgnd(CDC* pDC)
{
     return TRUE; // Prevent flickering by not erasing the background
}

void CRotoScopeView::OnLButtonDown(UINT nFlags, CPoint point)
{
     CRotoScopeDoc* pDoc = GetDocument();
     const CGrImage& image = pDoc->GetImage();

     // Ensure the click is within the image bounds
     if (point.x >= 0 && point.x < image.GetWidth() &&
          point.y >= 0 && point.y < image.GetHeight()) {
          pDoc->Mouse(point.x, point.y);
     }

     CView::OnLButtonDown(nFlags, point);
}

void CRotoScopeView::OnMouseMove(UINT nFlags, CPoint point)
{
     if (nFlags & MK_LBUTTON) {
          CRotoScopeDoc* pDoc = GetDocument();
          const CGrImage& image = pDoc->GetImage();

          // Ensure the drag is within the image bounds
          if (point.x >= 0 && point.x < image.GetWidth() &&
               point.y >= 0 && point.y < image.GetHeight()) {
               pDoc->Mouse(point.x, point.y);
          }
     }

     CView::OnMouseMove(nFlags, point);
}

void CRotoScopeView::OnRButtonDown(UINT nFlags, CPoint point)
{
     CRotoScopeDoc* pDoc = GetDocument();

     // Handle right-click interaction (e.g., rotation)
     if (point.x >= 0 && point.y >= 0) {
          int theta = 10; // Example fixed rotation angle
          CGrImage image = pDoc->GetImage(); // Create a modifiable copy of the image
          pDoc->RotateImage(image, theta);   // Pass the modifiable copy to RotateImage
          pDoc->SetImage(image);             // Update the document's image with the rotated one
          Invalidate();                      // Redraw the view after rotation
     }

     CView::OnRButtonDown(nFlags, point);
}

void CRotoScopeView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
     CRotoScopeDoc* pDoc = GetDocument();

     // Handle keyboard interactions for shortcuts (e.g., toggling mask visibility)
     switch (nChar) {
     case VK_SPACE: // Toggle mask visibility
          pDoc->ToggleMask();
          Invalidate(); // Redraw the view
          break;
     case VK_DELETE: // Clear selected mask
          pDoc->ClearMask();
          Invalidate();
          break;
     default:
          break;
     }

     CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
